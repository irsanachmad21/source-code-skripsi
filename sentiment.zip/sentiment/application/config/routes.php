<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'DatasetController';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Sentiment Analysis Routes
$route['dataset'] = 'DatasetController/index';
$route['preprocessing'] = 'PreprocessingController/index';
$route['word-analysis'] = 'WordAnalysisController/index';
$route['labeling'] = 'LabelingController/index';
$route['splitting'] = 'SplittingController/index';
$route['model-evaluation'] = 'ModelEvaluationController/index';
$route['actual-vs-predicted'] = 'SentimentResultController/index';
$route['conclusion'] = 'ConclusionController/index';
