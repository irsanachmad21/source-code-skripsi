<style>
    thead th {
        background-color: #343a40 !important;
        color: white !important;
    }
</style>

<div class="container-fluid px-4">
    <!-- Card: Tabel + Grafik Splitting -->
    <div class="card shadow-sm mb-5">
        <div class="card-header">
            <h5 class="mb-0">Splitting Distribution</h5>
        </div>
        <div class="card-body">
            <!-- Tabel Splitting -->
            <div class="table-responsive mb-4">
                <table class="table table-bordered table-striped table-hover text-center mb-0">
                    <thead>
                        <tr>
                            <th>Data Training</th>
                            <th>Data Testing</th>
                            <th>Total Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($splitting)) : ?>
                            <?php foreach ($splitting as $row) : ?>
                                <tr>
                                    <td><?= $row->data_training ?></td>
                                    <td><?= $row->data_testing ?></td>
                                    <td><?= $row->total ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="3">Data not found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Grafik Chart.js -->
            <div class="text-center">
                <canvas id="splittingChart" style="max-height: 300px;"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('splittingChart').getContext('2d');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Data Training', 'Data Testing'],
            datasets: [{
                label: 'Total ',
                data: [
                    <?= array_sum(array_map(fn($s) => $s->data_training, $splitting)) ?>,
                    <?= array_sum(array_map(fn($s) => $s->data_testing, $splitting)) ?>
                ],
                backgroundColor: ['#36b9cc', '#f6c23e']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
</script>
