<div class="container-fluid px-4">

    <!-- Word Cloud Section -->
    <div class="row">
        <div class="col-md-6 text-center">
            <h5>Word Cloud Before Preprocessing</h5>
            <img src="<?= base_url('assets/images/wc_sebelum_preprocessing.png') ?>" 
                 class="img-fluid border border-dark" 
                 alt="Word Cloud Sebelum Preprocessing">
        </div>
        <div class="col-md-6 text-center">
            <h5>Word Cloud After Preprocessing</h5>
            <img src="<?= base_url('assets/images/wc_sesudah_preprocessing.png') ?>" 
                 class="img-fluid border border-dark" 
                 alt="Word Cloud Sesudah Preprocessing">
        </div>
    </div>

    <!-- Frequency Count Section -->
    <div class="row mt-5">
        <div class="col-md-6 text-center">
            <h5>Word Frequency Before Preprocessing</h5>
            <img src="<?= base_url('assets/images/fk_sebelum_preprocessing.png') ?>" 
                 class="img-fluid border border-dark"
                 style="height: 250px; width: 600px;" 
                 alt="Frequency Count Sebelum Preprocessing">
        </div>
        <div class="col-md-6 text-center">
            <h5>Word Frequency After Preprocessing</h5>
            <img src="<?= base_url('assets/images/fk_sesudah_preprocessing.png') ?>" 
                 class="img-fluid border border-dark"
                 style="height: 250px; width: 600px;" 
                 alt="Frequency Count Sesudah Preprocessing">
        </div>
    </div>

</div>
