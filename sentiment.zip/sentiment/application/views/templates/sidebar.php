<?php
$current_controller = $this->router->fetch_class();
?>

<div class="sidebar">
    <h4 class="text-center mb-4">Sentiment Analysis</h4>
    <ul class="nav flex-column px-3">
        <li class="nav-item">
            <a class="nav-link text-white <?= ($current_controller === 'DatasetController') ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('dataset') ?>">
                <i class="bi bi-collection me-2"></i> Dataset
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?= ($current_controller === 'PreprocessingController') ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('preprocessing') ?>">
                <i class="bi bi-gear me-2"></i> Preprocessing
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?= ($current_controller === 'WordAnalysisController') ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('word-analysis') ?>">
                <i class="bi bi-search me-2"></i> Word Analysis
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?= ($current_controller === 'LabelingController') ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('labeling') ?>">
                <i class="bi bi-tags me-2"></i> Labeling
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?= ($current_controller === 'SplittingController') ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('splitting') ?>">
                <i class="bi bi-shuffle me-2"></i> Splitting
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?= ($current_controller === 'ModelEvaluationController') ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('model-evaluation') ?>">
                <i class="bi bi-bar-chart-line me-2"></i> Model Evaluation
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white <?= ($current_controller === 'SentimentResultController') ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('actual-vs-predicted') ?>">
                <i class="bi bi-graph-up-arrow me-2"></i> Actual vs Predicted
            </a>
        </li>

        <hr>

        <li class="nav-item">
            <a class="nav-link text-white <?= (strpos(uri_string(), 'conclusion') === 0) ? 'active bg-secondary rounded' : '' ?>" href="<?= site_url('/conclusion') ?>">
                <i class="bi bi-info-circle me-2"></i> Conclusion
            </a>
        </li>
    </ul>
</div>