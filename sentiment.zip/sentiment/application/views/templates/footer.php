</main> <!-- End of content -->

<footer class="py-3 text-center border-top mt-auto" style="background-color: #f2f3f3;">
    <span class="text-muted d-block small">Sentiment Analysis &copy; <?= date('Y') ?> - Created by Irsan Achmad Maulidan</span>
</footer>
