<style>
    thead th {
        background-color: #343a40 !important;
        color: white !important;
    }

    a {
        color: #343a40;
        text-decoration: none;
    }

    .pagination .page-item.active .page-link {
        color: white !important;
        background-color: #343a40 !important;
        border-color: #343a40 !important;
    }
</style>

<div class="container-fluid px-4 mt-2">
    <form method="get" action="<?= base_url('/preprocessing') ?>" class="mb-3 d-flex align-items-center gap-2">

        <label for="order" class="mb-0">Order by:</label>
        <select name="order" id="order" class="form-select" style="width: 150px;">
            <option value="asc" <?= ($order ?? '') === 'asc' ? 'selected' : '' ?>>Ascending</option>
            <option value="desc" <?= ($order ?? '') === 'desc' ? 'selected' : '' ?>>Descending</option>
        </select>

        <label for="sort" class="mb-0">Type:</label>
        <select name="sort" id="sort" class="form-select" style="width: 150px;">
            <option value="id_preprocessing" <?= ($sort ?? '') === 'id_preprocessing' ? 'selected' : '' ?>>ID</option>
            <option value="text" <?= ($sort ?? '') === 'text' ? 'selected' : '' ?>>Text</option>
            <option value="cleaning" <?= ($sort ?? '') === 'cleaning' ? 'selected' : '' ?>>Cleaning</option>
            <option value="case_folding" <?= ($sort ?? '') === 'case_folding' ? 'selected' : '' ?>>Case Folding</option>
            <option value="normalization" <?= ($sort ?? '') === 'normalization' ? 'selected' : '' ?>>Normalization</option>
            <option value="tokenizing" <?= ($sort ?? '') === 'tokenizing' ? 'selected' : '' ?>>Tokenizing</option>
            <option value="stopword_removal" <?= ($sort ?? '') === 'stopword_removal' ? 'selected' : '' ?>>Stopword Removal</option>
            <option value="stemming" <?= ($sort ?? '') === 'stemming' ? 'selected' : '' ?>>Stemming</option>
        </select>

        <button type="submit" class="btn" style="background-color: #343a40; color: white;">Find</button>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Text</th>
                    <th>Cleaning</th>
                    <th>Case Folding</th>
                    <th>Normalization</th>
                    <th>Tokenizing</th>
                    <th>Stopword Removal</th>
                    <th>Stemming</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($preprocessing)) : ?>
                    <?php foreach ($preprocessing as $data) : ?>
                        <tr>
                            <td><?= $data->id_preprocessing ?></td>
                            <td><?= $data->text ?></td>
                            <td><?= $data->cleaning ?></td>
                            <td><?= $data->case_folding ?></td>
                            <td><?= $data->normalization ?></td>
                            <td><?= $data->tokenizing ?></td>
                            <td><?= $data->stopword_removal ?></td>
                            <td><?= $data->stemming ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8" class="text-center">Data not found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Tampilkan pagination -->
    <div class="d-flex justify-content-start">
        <?= $pagination ?>
    </div>
</div>