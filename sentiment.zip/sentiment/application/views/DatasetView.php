<style>
    thead th {
        background-color: #343a40 !important;
        color: white !important;
    }

    a {
        color: #343a40;
        text-decoration: none;
    }

    .pagination .page-item.active .page-link {
        color: white !important;
        background-color: #343a40 !important;
        border-color: #343a40 !important;
    }
</style>

<div class="container-fluid px-4 mt-2">
    <form method="get" action="<?= base_url('/dataset') ?>" class="mb-3 d-flex align-items-center gap-2">

        <label for="order" class="mb-0">Order by:</label>
        <select name="order" id="order" class="form-select" style="width: 150px;">
            <option value="asc" <?= ($order ?? '') === 'asc' ? 'selected' : '' ?>>Ascending</option>
            <option value="desc" <?= ($order ?? '') === 'desc' ? 'selected' : '' ?>>Descending</option>
        </select>

        <label for="type" class="mb-0">Type:</label>
        <select name="sort" id="type" class="form-select" style="width: 150px;">
            <option value="id_dataset" <?= ($sort ?? '') === 'id_dataset' ? 'selected' : '' ?>>ID</option>
            <option value="username" <?= ($sort ?? '') === 'username' ? 'selected' : '' ?>>Username</option>
            <option value="text" <?= ($sort ?? '') === 'text' ? 'selected' : '' ?>>Text</option>
            <option value="create_at" <?= ($sort ?? '') === 'create_at' ? 'selected' : '' ?>>Created At</option>
        </select>

        <button type="submit" class="btn" style="background-color: #343a40; color: white;">Find</button>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th style="width: 5%;">ID</th>
                    <th style="width: 20%;">Username</th>
                    <th style="width: 55%;">Text</th>
                    <th style="width: 20%;">Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($dataset)) : ?>
                    <?php foreach ($dataset as $data) : ?>
                        <tr>
                            <td><?= $data->id_dataset ?></td>
                            <td><?= $data->username ?></td>
                            <td><?= $data->text ?></td>
                            <td><?= date('d F Y - H:i:s', strtotime($data->create_at)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4" class="text-center">Data not found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Tampilkan pagination -->
    <div class="d-flex justify-content-start">
        <?= $pagination ?>
    </div>
</div>