<style>
    thead th {
        background-color: #343a40 !important;
        color: white !important;
    }

    a {
        color: #343a40;
        text-decoration: none;
    }

    .pagination .page-item.active .page-link {
        color: white !important;
        background-color: #343a40 !important;
        border-color: #343a40 !important;
    }
</style>

<div class="container-fluid px-4 mt-2">
    <form method="get" action="<?= base_url('/labeling') ?>" class="mb-3 d-flex align-items-center gap-2">
        <label for="order" class="mb-0">Order by:</label>
        <select name="order" id="order" class="form-select" style="width: 150px;">
            <option value="asc" <?= ($order ?? '') === 'asc' ? 'selected' : '' ?>>Ascending</option>
            <option value="desc" <?= ($order ?? '') === 'desc' ? 'selected' : '' ?>>Descending</option>
        </select>

        <label for="sort" class="mb-0">Type:</label>
        <select name="sort" id="sort" class="form-select" style="width: 150px;">
            <option value="id_labeling" <?= ($sort ?? '') === 'id_labeling' ? 'selected' : '' ?>>ID</option>
            <option value="username" <?= ($sort ?? '') === 'username' ? 'selected' : '' ?>>Username</option>
            <option value="text" <?= ($sort ?? '') === 'text' ? 'selected' : '' ?>>Text</option>
            <option value="label" <?= ($sort ?? '') === 'label' ? 'selected' : '' ?>>Label</option>
        </select>

        <button type="submit" class="btn" style="background-color: #343a40; color: white;">Find</button>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th style="width: 5%;">ID</th>
                    <th style="width: 20%;">Username</th>
                    <th style="width: 55%;">Text</th>
                    <th style="width: 20%;" class="text-center">Label</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($labeling)) : ?>
                    <?php foreach ($labeling as $data) : ?>
                        <tr>
                            <td><?= $data->id_labeling ?></td>
                            <td><?= htmlspecialchars($data->username) ?></td>
                            <td><?= htmlspecialchars($data->text) ?></td>
                            <td class="text-center <?= $data->label == 'Positive' ? 'text-success' : ($data->label == 'Negative' ? 'text-danger' : '') ?>">
                                <?= htmlspecialchars($data->label) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4" class="text-center">Data not found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Tampilkan pagination -->
    <div class="d-flex justify-content-start">
        <?= $pagination ?>
    </div>

    <hr>

    <!-- Chart Section with Card Header and Horizontal Table -->
    <div class="mt-5">
        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0">Labeling Distribution</h5>
            </div>
            <div class="card-body">
                <!-- Horizontal table for Positive, Negative, and Total counts -->
                <table class="table table-bordered table-striped text-center mb-4">
                    <thead>
                        <tr>
                            <th>Positive</th>
                            <th>Negative</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?= $positive_count ?></td>
                            <td><?= $negative_count ?></td>
                            <td><?= $positive_count + $negative_count ?></td>
                        </tr>
                    </tbody>
                </table>

                <!-- Chart canvas -->
                <canvas id="labelChart" height="100"></canvas>
            </div>
        </div>
    </div>

    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('labelChart').getContext('2d');
        const labelChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Positive', 'Negative'],
                datasets: [{
                    label: 'Total',
                    data: [<?= $positive_count ?>, <?= $negative_count ?>],
                    backgroundColor: ['#1cc88a', '#e74a3b'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>

</div>