<style>
    thead th {
        background-color: #343a40 !important;
        color: white !important;
    }

    td {
        background-color: #ffffff !important;
    }
</style>

<div class="container-fluid px-4">
    <!-- Classification Report Table -->
    <div class="card mb-4">
        <div class="card-header">
            <h4>Classification Report</h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped text-center">
                <thead class="table-primary">
                    <tr>
                        <th>Accuracy</th>
                        <th>Precision (Positive)</th>
                        <th>Recall (Positive)</th>
                        <th>F1 Score (Positive)</th>
                        <th>Precision (Negative)</th>
                        <th>Recall (Negative)</th>
                        <th>F1 Score (Negative)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($class_report as $report): ?>
                        <tr>
                            <td><?= number_format($report->accuracy, 4) ?></td>
                            <td><?= number_format($report->precision_positive, 2) ?></td>
                            <td><?= number_format($report->recall_positive, 2) ?></td>
                            <td><?= number_format($report->f1_score_positive, 2) ?></td>
                            <td><?= number_format($report->precision_negative, 2) ?></td>
                            <td><?= number_format($report->recall_negative, 2) ?></td>
                            <td><?= number_format($report->f1_score_negative, 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Chart for Classification Report -->
            <canvas id="classificationChart" height="120"></canvas>
        </div>
    </div>

    <hr>

    <!-- Confusion Matrix Table -->
    <div class="card mb-4">
        <div class="card-header">
            <h4>Confusion Matrix</h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped text-center">
                <thead class="table-secondary">
                    <tr>
                        <th>True Positive</th>
                        <th>False Positive</th>
                        <th>True Negative</th>
                        <th>False Negative</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($confusion_matrix as $cm): ?>
                        <tr>
                            <td><?= $cm->true_positive ?></td>
                            <td><?= $cm->false_positive ?></td>
                            <td><?= $cm->true_negative ?></td>
                            <td><?= $cm->false_negative ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Chart for Confusion Matrix -->
            <canvas id="confusionChart" height="120"></canvas>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Classification Chart
    const classificationCtx = document.getElementById('classificationChart').getContext('2d');
    const classificationChart = new Chart(classificationCtx, {
        type: 'bar',
        data: {
            labels: [
                'Accuracy', 'Precision (Positive)', 'Recall (Positive)', 'F1 (Positive)',
                'Precision (Negative)', 'Recall (Negative)', 'F1 (Negative)'
            ],
            datasets: [{
                data: [
                    <?= number_format($report->accuracy * 100, 2) ?>,
                    <?= number_format($report->precision_positive * 100, 2) ?>,
                    <?= number_format($report->recall_positive * 100, 2) ?>,
                    <?= number_format($report->f1_score_positive * 100, 2) ?>,
                    <?= number_format($report->precision_negative * 100, 2) ?>,
                    <?= number_format($report->recall_negative * 100, 2) ?>,
                    <?= number_format($report->f1_score_negative * 100, 2) ?>
                ],
                backgroundColor: [
                    '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e',
                    '#e74a3b', '#858796', '#5a5c69'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw !== undefined ? context.raw : 0;
                            return `${value.toFixed(2)}%`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });



    // Confusion Matrix Chart
    const confusionCtx = document.getElementById('confusionChart').getContext('2d');
    const confusionChart = new Chart(confusionCtx, {
        type: 'bar',
        data: {
            labels: ['True Positive', 'False Positive', 'True Negative', 'False Negative'],
            datasets: [{
                data: [
                    <?= $cm->true_positive ?>,
                    <?= $cm->false_positive ?>,
                    <?= $cm->true_negative ?>,
                    <?= $cm->false_negative ?>
                ],
                backgroundColor: ['#1cc88a', '#e74a3b', '#4e73df', '#f6c23e']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>