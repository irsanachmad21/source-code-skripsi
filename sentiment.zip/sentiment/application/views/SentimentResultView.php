<style>
    thead th {
        background-color: #343a40 !important;
        color: white !important;
    }

    a {
        color: #343a40;
        text-decoration: none;
    }

    .pagination .page-item.active .page-link {
        color: white !important;
        background-color: #343a40 !important;
        border-color: #343a40 !important;
    }
</style>

<div class="container-fluid px-4 mt-2">
    <form method="get" action="<?= base_url('/SentimentResultController') ?>" class="mb-3 d-flex align-items-center gap-2">
        <label for="order" class="mb-0">Order by:</label>
        <select name="order" id="order" class="form-select" style="width: 150px;">
            <option value="asc" <?= ($order ?? '') === 'asc' ? 'selected' : '' ?>>Ascending</option>
            <option value="desc" <?= ($order ?? '') === 'desc' ? 'selected' : '' ?>>Descending</option>
        </select>

        <label for="sort" class="mb-0">Sort by:</label>
        <select name="sort" id="sort" class="form-select" style="width: 150px;">
            <option value="id_sent_result" <?= ($sort ?? '') === 'id_sent_result' ? 'selected' : '' ?>>ID</option>
            <option value="stemming" <?= ($sort ?? '') === 'stemming' ? 'selected' : '' ?>>Stemming</option>
            <option value="actual" <?= ($sort ?? '') === 'actual' ? 'selected' : '' ?>>Actual</option>
            <option value="predicted" <?= ($sort ?? '') === 'predicted' ? 'selected' : '' ?>>Predicted</option>
        </select>

        <button type="submit" class="btn" style="background-color: #343a40; color: white;">Find</button>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th style="width: 5%;">ID</th>
                    <th style="width: 55%;">Stemming</th>
                    <th style="width: 20%;" class="text-center">Actual</th>
                    <th style="width: 20%;" class="text-center">Predicted</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($sentiment)) : ?>
                    <?php foreach ($sentiment as $data) : ?>
                        <tr>
                            <td><?= $data->id_sent_result ?></td>
                            <td><?= htmlspecialchars($data->stemming) ?></td>
                            <td class="text-center <?= $data->actual == 'Positive' ? 'text-success' : ($data->actual == 'Negative' ? 'text-danger' : '') ?>">
                                <?= htmlspecialchars($data->actual) ?>
                            </td>
                            <td class="text-center <?= $data->predicted == 'Positive' ? 'text-success' : ($data->predicted == 'Negative' ? 'text-danger' : '') ?>">
                                <?= htmlspecialchars($data->predicted) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="4" class="text-center">Data not found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Tampilkan pagination -->
    <div class="d-flex justify-content-start">
        <?= $pagination ?>
    </div>

    <hr>

    <!-- Section: Grafik Actual vs Predicted -->
    <div class="row mt-5">
        <!-- Grafik Actual -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0">Actual Label</h5>
                </div>
                <div class="card-body">
                    <!-- Tabel Ringkasan Actual -->
                    <table class="table table-sm table-bordered text-center mb-4">
                        <thead class="table-dark">
                            <tr>
                                <th>Positive</th>
                                <th>Negative</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?= $actual_positive ?></td>
                                <td><?= $actual_negative ?></td>
                                <td><?= $actual_positive + $actual_negative ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- Grafik -->
                    <canvas id="actualChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Grafik Predicted -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0">Predicted Label</h5>
                </div>
                <div class="card-body">
                    <!-- Tabel Ringkasan Predicted -->
                    <table class="table table-sm table-bordered text-center mb-4">
                        <thead class="table-dark">
                            <tr>
                                <th>Positive</th>
                                <th>Negative</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?= $predicted_positive ?></td>
                                <td><?= $predicted_negative ?></td>
                                <td><?= $predicted_positive + $predicted_negative ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- Grafik -->
                    <canvas id="predictedChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const actualCtx = document.getElementById('actualChart').getContext('2d');
        const predictedCtx = document.getElementById('predictedChart').getContext('2d');

        // Grafik Actual
        new Chart(actualCtx, {
            type: 'bar',
            data: {
                labels: ['Positive', 'Negative'],
                datasets: [{
                    label: 'Total ',
                    data: [<?= $actual_positive ?>, <?= $actual_negative ?>],
                    backgroundColor: ['#1cc88a', '#e74a3b']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });

        // Grafik Predicted
        new Chart(predictedCtx, {
            type: 'bar',
            data: {
                labels: ['Positive', 'Negative'],
                datasets: [{
                    label: 'Total',
                    data: [<?= $predicted_positive ?>, <?= $predicted_negative ?>],
                    backgroundColor: ['#1cc88a', '#e74a3b']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>

</div>