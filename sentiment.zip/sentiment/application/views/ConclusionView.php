<div class="container-fluid px-4 my-4">
    <h5 style="line-height: 1.5;" class="text-center fw-bold mb-5">
        ANALYSIS OF NETIZEN SENTIMENT TOWARDS INDONESIAN U17 NATIONAL TEAM TOWARDS 2025 WORLD CUP USING WEB-BASED NAÏVE BAYES ALGORITHM
    </h5>
    <div class="row align-items-center">
        <div class="col-md-4 text-center">
            <img src="<?= base_url('assets/images/timnas.jpg') ?>" class="img-fluid rounded" style="max-width: 310px;" alt="Timnas Indonesia">
        </div>

        <div class="col-md-8 pe-md-5">
            <p style="text-align: justify;">
                Social media has become the main platform for people to express their opinions, including in the field of sports. One of the moments that has become the public spotlight is the success of the Indonesian U17 National Team in reaching the 2025 U17 World Cup through the official qualification route. This study aims to analyze netizen sentiment towards this achievement using the Naïve Bayes algorithm as a classification method. Data was collected from the comments column on one of the uploads of the official TikTok account @timnasindonesia, then entered the preprocessing stage before being classified into positive and negative sentiments. The results showed that the Naïve Bayes model achieved an accuracy of 83.44%. The model performed very well in classifying positive comments, with a precision of 88%, a recall of 91%, and an F1-score of 89%. However, for negative comments, performance was still less than optimal with a precision of 68%, a recall of 58%, and an F1-score of 63%. Based on the confusion matrix, the model was able to classify 105 data as True Positive and 21 data as True Negative, with 15 False Positive and 10 False Negative. Overall, the data distribution shows that the majority of netizen comments on the U17 National Team are positive. These results are expected to be the basis for developing a sentiment analysis system in the future, especially in the context of national sports.
            </p>
        </div>
    </div>
</div>
