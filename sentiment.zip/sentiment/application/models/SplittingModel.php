<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SplittingModel extends CI_Model {

    public function get_all_data()
    {
        return $this->db->get('splitting')->result();
    }
}
