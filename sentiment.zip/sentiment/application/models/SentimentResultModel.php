<?php
defined('BASEPATH') or exit('No direct script access allowed');

class SentimentResultModel extends CI_Model
{

    public function get_all_data()
    {
        return $this->db->get('sentiment_result')->result();
    }

    public function get_total_rows()
    {
        return $this->db->count_all('sentiment_result');
    }

    public function get_paginated_data($limit, $start, $sort, $order)
    {
        return $this->db->order_by($sort, $order)
            ->get('sentiment_result', $limit, $start)
            ->result();
    }

    public function count_label($column, $value)
    {
        return $this->db->where($column, $value)->count_all_results('sentiment_result');
    }
}
