<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PreprocessingModel extends CI_Model
{

    public function get_all_data()
    {
        return $this->db->get('preprocessing')->result();
    }

    public function get_paginated_data($limit, $start, $sort, $order)
    {
        return $this->db
            ->order_by($sort, $order)
            ->limit($limit, $start)
            ->get('preprocessing')
            ->result();
    }

    public function get_total_rows()
    {
        return $this->db->count_all('preprocessing');
    }
}
