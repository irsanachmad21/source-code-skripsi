<?php
defined('BASEPATH') or exit('No direct script access allowed');

class DatasetModel extends CI_Model
{

    public function get_all_data()
    {
        return $this->db->get('dataset')->result();
    }

    public function get_paginated_data($limit, $start, $sort = 'id_dataset', $order = 'asc')
    {
        $this->db->order_by($sort, $order);
        $query = $this->db->get('dataset', $limit, $start);
        return $query->result();
    }

    public function get_total_rows()
    {
        return $this->db->count_all('dataset');
    }
}
