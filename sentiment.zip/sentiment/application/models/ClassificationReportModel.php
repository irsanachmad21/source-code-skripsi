<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ClassificationReportModel extends CI_Model
{

    public function get_all_data()
    {
        return $this->db->get('classification_report')->result();
    }
}
