<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ConfusionMatrixModel extends CI_Model {

    public function get_all_data()
    {
        return $this->db->get('confusion_matrix')->result();
    }
}
