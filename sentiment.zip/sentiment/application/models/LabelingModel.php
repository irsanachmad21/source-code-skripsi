<?php
defined('BASEPATH') or exit('No direct script access allowed');

class LabelingModel extends CI_Model
{

    public function get_all_data()
    {
        return $this->db->get('labeling')->result();
    }

    public function get_total_rows()
    {
        return $this->db->count_all('labeling');
    }

    public function get_paginated_data($limit, $offset, $sort, $order)
    {
        return $this->db
            ->order_by($sort, $order)
            ->get('labeling', $limit, $offset)
            ->result();
    }

    public function count_by_label($label)
    {
        return $this->db->where('label', $label)->count_all_results('labeling');
    }
}
