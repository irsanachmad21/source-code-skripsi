<?php
defined('BASEPATH') or exit('No direct script access allowed');

class SentimentResultController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('SentimentResultModel');
        $this->load->library('pagination');
    }

    public function index()
    {
        $sort = $this->input->get('sort') ?? 'id_sent_result';
        $order = $this->input->get('order') ?? 'asc';

        // Daftar kolom yang diizinkan untuk sort
        $allowed_sort = ['id_sent_result', 'stemming', 'actual', 'predicted'];

        if (!in_array($sort, $allowed_sort)) {
            $sort = 'id_sent_result';
        }

        $order = ($order === 'desc') ? 'desc' : 'asc';

        // Konfigurasi pagination
        $config['base_url'] = base_url('SentimentResultController/index') . "?sort=$sort&order=$order";
        $config['total_rows'] = $this->SentimentResultModel->get_total_rows();
        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';

        // Styling untuk Bootstrap pagination
        $config['full_tag_open'] = '<nav><ul class="pagination">';
        $config['full_tag_close'] = '</ul></nav>';
        $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close'] = '</span></li>';
        $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close'] = '</span></li>';
        $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close'] = '</span></li>';
        $config['cur_tag_open'] = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close'] = '</span></li>';
        $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close'] = '</span></li>';

        $this->pagination->initialize($config);

        $page = $this->input->get('page') ? (int)$this->input->get('page') : 0;

        $data['sentiment'] = $this->SentimentResultModel->get_paginated_data($config['per_page'], $page, $sort, $order);
        $data['pagination'] = $this->pagination->create_links();
        $data['page_title'] = 'Actual vs Predicted';
        $data['sort'] = $sort;
        $data['order'] = $order;

        $data['actual_positive'] = $this->SentimentResultModel->count_label('actual', 'Positive');
        $data['actual_negative'] = $this->SentimentResultModel->count_label('actual', 'Negative');
        $data['predicted_positive'] = $this->SentimentResultModel->count_label('predicted', 'Positive');
        $data['predicted_negative'] = $this->SentimentResultModel->count_label('predicted', 'Negative');

        $this->load->view('templates/header', ['page_title' => $data['page_title']]);
        $this->load->view('SentimentResultView', $data);
        $this->load->view('templates/footer');
    }
}
