<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ConclusionController extends CI_Controller
{

    public function index()
    {
        $data['page_title'] = 'Conclusion';
        $this->load->view('templates/header', ['page_title' => $data['page_title']]);
        $this->load->view('ConclusionView', $data);
        $this->load->view('templates/footer');
    }
}
