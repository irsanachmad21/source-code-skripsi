<?php
defined('BASEPATH') or exit('No direct script access allowed');

class WordAnalysisController extends CI_Controller
{
    public function index()
    {
        $data['page_title'] = 'Word Analysis';
        $this->load->view('templates/header', ['page_title' => $data['page_title']]);
        $this->load->view('WordAnalysisView', $data);
        $this->load->view('templates/footer');
    }
}
