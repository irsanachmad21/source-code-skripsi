<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ModelEvaluationController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('ClassificationReportModel');
        $this->load->model('ConfusionMatrixModel');
    }

    public function index()
    {
        $data['class_report'] = $this->ClassificationReportModel->get_all_data();
        $data['confusion_matrix'] = $this->ConfusionMatrixModel->get_all_data();
        
        $data['page_title'] = 'Model Evaluation';
        $this->load->view('templates/header', ['page_title' => $data['page_title']]);
        $this->load->view('ModelEvaluationView', $data);
        $this->load->view('templates/footer');
    }
}
