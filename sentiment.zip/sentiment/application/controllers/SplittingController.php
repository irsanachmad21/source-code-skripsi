<?php
defined('BASEPATH') or exit('No direct script access allowed');

class SplittingController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('SplittingModel');
    }

    public function index()
    {
        $data['splitting'] = $this->SplittingModel->get_all_data();
        
        $data['page_title'] = 'Splitting';
        $this->load->view('templates/header', ['page_title' => $data['page_title']]);
        $this->load->view('SplittingView', $data);
        $this->load->view('templates/footer');
    }
}
